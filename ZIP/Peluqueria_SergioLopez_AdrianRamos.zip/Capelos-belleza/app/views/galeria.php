<!DOCTYPE html>
<html>

<head>
    <?php require "app/views/parts/head.php" ?>
</head>

<body>
    <?php require "app/views/parts/header.php" ?>

    <hr>

    <hr>
    <?php require "app/views/parts/footer.php" ?>
</body>

</html>