<div id="encabezado">
    <div id="menu">
        <img src="../img/BELLEZAcapello-01.jpg" alt="logo">
        <nav></nav>
    </div>
    <div id="info">

    </div>
    <img src="" alt="foto-carrusel">
    <div id="cita"></div>
</div>