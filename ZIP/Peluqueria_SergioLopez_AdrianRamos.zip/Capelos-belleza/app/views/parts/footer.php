<footer>
    <div id="redes">

    </div>
    <div id="privacidad">
        <p>Derechos reservados &copy;2010. Sujeto a <strong>Creative Commons license</strong>.</p>
    </div>

</footer>