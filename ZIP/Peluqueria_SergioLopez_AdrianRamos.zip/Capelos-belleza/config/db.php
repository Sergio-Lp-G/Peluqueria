<?php
#config/db.php
namespace Config;

const DSN = 'mysql:dbname=capelos;host=db';
const USER = 'root';
const PASSWORD = 'password';
