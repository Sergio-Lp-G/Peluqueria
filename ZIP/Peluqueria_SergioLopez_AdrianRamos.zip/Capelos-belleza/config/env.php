<?php
    define ('PATH', '/');
?>