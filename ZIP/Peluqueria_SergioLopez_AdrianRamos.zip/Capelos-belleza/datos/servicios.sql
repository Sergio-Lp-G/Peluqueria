INSERT INTO `servicio` (`id`, `nombre`,`categoria`, `duracion`, `precio`) VALUES
(1, 'Pixie','corte', 50, 30),
(2, 'Capas','corte', 50, 35),
(3, 'Bob','corte', 50, 40),
(4, 'Trenzas','peinado', 40, 20),
(5, 'Italiano','peinado', 45, 25),
(6, 'Coca','peinado', 50, 30),
(7, 'Entero','coloracion', 60, 40),
(8, 'Mechas','coloracion', 70, 30),
(9, 'Metalico','coloracion', 60, 40),
(10, 'Bigudi','cambio_temporal', 40, 20),
(11, 'Ondas_al_agua','cambio_temporal', 30, 15),
(12, 'Alisado','cambio_temporal', 40, 15)
;